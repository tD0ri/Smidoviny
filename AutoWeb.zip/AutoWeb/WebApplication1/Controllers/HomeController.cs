﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controlers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            Auto auto = new Auto();
            ViewBag.typ = auto.getTypAuta();
            ViewBag.barva = auto.getBarva();
            ViewBag.rychlost = auto.getMaxRychlost();
            ViewBag.obsah = auto.getObsahMotoru();
            return View();
        }
        public IActionResult Spotreba([FromQuery] int l, int km)
        {
            Auto auto = new Auto();
            ViewBag.spotr = auto.Spotreba(l, km);
            return View();
        }
    }
}
