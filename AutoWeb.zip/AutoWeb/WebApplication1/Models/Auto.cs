﻿using System.Formats.Asn1;

namespace WebApplication1.Models
{
    public class Auto
    {
        string typAuta;
        string barva;
        int maxRychlost;
        int obsahMotoru;


        public void setInformace(string typAuta, string barva, int maxRychlost, int obsahMotoru)
        {
            this.typAuta = typAuta;
            this.barva = barva;
            this.maxRychlost = maxRychlost;
            this.obsahMotoru = obsahMotoru;

        }

        public string getTypAuta() 
        {
            typAuta = "Audi";
            return typAuta;
        }
        public string getBarva() 
        {
            barva = "modrá";
            return barva;
        }
        public int getMaxRychlost()
        {
            maxRychlost = 200;
            return maxRychlost;
        }
        public int getObsahMotoru()
        {
            obsahMotoru = 50;
            return obsahMotoru;
        }

        public int Spotreba(int l, int km) 
        {
            int spotreba;
            spotreba = l / km * 100;
            return spotreba;
        }
    
    }
}
